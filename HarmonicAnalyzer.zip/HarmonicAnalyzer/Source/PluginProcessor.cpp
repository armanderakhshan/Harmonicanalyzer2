#include "PluginProcessor.h"
#include "PluginEditor.h"

HarmonicProcessor::HarmonicProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
}

HarmonicProcessor::~HarmonicProcessor()
{
    if (worker.joinable()) worker.join();
}

void HarmonicProcessor::prepareToPlay (double sampleRate, int)
{
    sr = sampleRate;
    if (! capturing.load())
    {
        capBuf.assign ((size_t) (sampleRate * 180.0), 0.0f);   // up to 3 minutes of live capture
        capN = 0;
    }
}

bool HarmonicProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    auto o = l.getMainOutputChannelSet();
    return (o == juce::AudioChannelSet::mono() || o == juce::AudioChannelSet::stereo()) && o == l.getMainInputChannelSet();
}

void HarmonicProcessor::processBlock (juce::AudioBuffer<float>& buf, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buf.getNumSamples(), chs = buf.getNumChannels();

    if (capturing.load() && ! capBuf.empty())
    {
        int w = capN.load();
        const int cap = (int) capBuf.size();
        for (int i = 0; i < n && w < cap; ++i, ++w)
        {
            float s = 0;
            for (int c = 0; c < chs; ++c) s += buf.getReadPointer (c)[i];
            capBuf[(size_t) w] = s / (float) std::max (1, chs);
        }
        capN.store (w);
    }

    // Standalone: silence the output (avoids mic feedback). As a plugin: pass audio through untouched.
    if (wrapperType == wrapperType_Standalone) buf.clear();
}

void HarmonicProcessor::launch (Loader loader)
{
    if (busy.exchange (true)) return;
    if (worker.joinable()) worker.join();
    setStatus ("Analyzing...");
    sendChangeMessage();
    worker = std::thread ([this, loader = std::move (loader)] {
        std::vector<float> data; double rate = 0; juce::String err;
        hm::Result r;
        if (loader (data, rate, err)) r = hm::analyze (data, rate);
        {
            const juce::ScopedLock l (lock);
            result = r;
            status = r.ok ? ("Done - analyzed " + juce::String ((int) r.seconds) + " s of audio.")
                          : (err.isNotEmpty() ? err : juce::String ("Audio too short (need at least 10 s)."));
        }
        busy = false;
        sendChangeMessage();
    });
}

void HarmonicProcessor::analyseFile (const juce::File& f)
{
    launch ([f] (std::vector<float>& out, double& rate, juce::String& err) {
        juce::AudioFormatManager fm; fm.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> rd (fm.createReaderFor (f));
        if (rd == nullptr || rd->lengthInSamples <= 0) { err = "Could not read this file."; return false; }
        rate = rd->sampleRate;
        const juce::int64 n = std::min<juce::int64> (rd->lengthInSamples, (juce::int64) (rate * 100.0));
        const juce::int64 start = (rd->lengthInSamples - n) / 2;
        juce::AudioBuffer<float> b ((int) rd->numChannels, (int) n);
        rd->read (&b, 0, (int) n, start, true, true);
        out.assign ((size_t) n, 0.0f);
        for (int c = 0; c < b.getNumChannels(); ++c)
            for (int i = 0; i < (int) n; ++i) out[(size_t) i] += b.getReadPointer (c)[i] / (float) b.getNumChannels();
        return true;
    });
}

void HarmonicProcessor::startCapture()
{
    capN = 0;
    capturing = true;
    setStatus ("Capturing... play the song, then press Stop & Analyze.");
    sendChangeMessage();
}

void HarmonicProcessor::stopCaptureAndAnalyse()
{
    capturing = false;
    const int n = capN.load();
    std::vector<float> copy (capBuf.begin(), capBuf.begin() + n);
    const double rate = sr;
    launch ([copy = std::move (copy), rate] (std::vector<float>& out, double& r, juce::String&) { out = copy; r = rate; return true; });
}

juce::AudioProcessorEditor* HarmonicProcessor::createEditor() { return new HarmonicEditor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new HarmonicProcessor(); }
