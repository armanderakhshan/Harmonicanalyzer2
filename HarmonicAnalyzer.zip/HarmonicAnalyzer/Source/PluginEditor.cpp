#include "PluginEditor.h"

HarmonicEditor::HarmonicEditor (HarmonicProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    setSize (640, 560);
    addAndMakeVisible (loadBtn); addAndMakeVisible (liveBtn); addAndMakeVisible (statusLbl); addAndMakeVisible (out);

    out.setMultiLine (true, false);
    out.setReadOnly (true);
    out.setFont (juce::Font (juce::FontOptions (juce::Font::getDefaultMonospacedFontName(), 14.0f, juce::Font::plain)));
    statusLbl.setJustificationType (juce::Justification::centredLeft);

    loadBtn.onClick = [this] {
        chooser = std::make_unique<juce::FileChooser> ("Select a song", juce::File(), "*.mp3;*.wav;*.aif;*.aiff;*.flac;*.m4a;*.aac;*.ogg;*.caf");
        chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                              [this] (const juce::FileChooser& fc) { auto f = fc.getResult(); if (f.existsAsFile()) proc.analyseFile (f); });
    };
    liveBtn.onClick = [this] {
        if (proc.isCapturing()) proc.stopCaptureAndAnalyse(); else proc.startCapture();
        refresh();
    };

    proc.addChangeListener (this);
    startTimerHz (2);
    refresh();
}

HarmonicEditor::~HarmonicEditor() { proc.removeChangeListener (this); }

void HarmonicEditor::paint (juce::Graphics& g) { g.fillAll (juce::Colour (0xff15151d)); }

void HarmonicEditor::resized()
{
    auto r = getLocalBounds().reduced (14);
    auto row = r.removeFromTop (34);
    loadBtn.setBounds (row.removeFromLeft (r.getWidth() / 2 - 6));
    row.removeFromLeft (12);
    liveBtn.setBounds (row);
    r.removeFromTop (8);
    statusLbl.setBounds (r.removeFromTop (26));
    r.removeFromTop (6);
    out.setBounds (r);
}

void HarmonicEditor::timerCallback()
{
    if (proc.isCapturing())
        statusLbl.setText ("Capturing... " + juce::String (proc.capturedSeconds(), 1) + " s (need 10 s or more)", juce::dontSendNotification);
}

void HarmonicEditor::refresh()
{
    liveBtn.setButtonText (proc.isCapturing() ? "Stop & Analyze" : "Start live capture");
    loadBtn.setEnabled (! proc.isBusy());
    statusLbl.setText (proc.getStatus(), juce::dontSendNotification);

    auto r = proc.getResult();
    if (! r.ok) { out.setText ("Drop an audio file here or press the button.\n\nIn Logic Pro: insert on a track, press 'Start live capture', play the song, then 'Stop & Analyze'.", false); return; }

    juce::String t;
    t << "KEY      " << hm::keyName (r.pc, r.minor) << "   (confidence " << juce::String (juce::jlimit (0.0f, 1.0f, r.conf) * 100.0f, 0) << "%)\n"
      << "CAMELOT  " << hm::camelotOf (r.pc, r.minor) << "\n"
      << "BPM      " << juce::String (r.bpm, 1) << "   (half " << juce::String (r.bpm / 2, 1) << " / double " << juce::String (r.bpm * 2, 1) << ")\n"
      << "MIX BPM  " << juce::String (r.bpm * 0.94, 1) << " - " << juce::String (r.bpm * 1.06, 1) << "  (+/-6%)\n\n"
      << "TOP CHORDS\n";
    for (auto& c : r.topChords) t << "  " << c.first.paddedRight (' ', 6) << juce::String (c.second, 0) << "%\n";
    t << "\nPROGRESSION\n  ";
    for (size_t i = 0; i < r.progression.size() && i < 32; ++i) t << r.progression[i] << (i + 1 < r.progression.size() ? " > " : "");
    t << "\n\nHARMONIC MIXING GUIDE (Camelot)\n";
    for (auto& m : r.mix) t << "  " << m.code.paddedRight (' ', 4) << m.key.paddedRight (' ', 12) << m.type << "\n";
    out.setText (t, false);
}
