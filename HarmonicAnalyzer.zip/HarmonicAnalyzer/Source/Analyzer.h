#pragma once
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <cmath>
#include <map>
#include <vector>

// Offline music analysis: key (Krumhansl-Schmuckler), BPM (onset autocorrelation),
// chords (chroma template matching) and Camelot-wheel mixing suggestions.
namespace hm
{
static const char* const NOTE[12] = {"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
static const int MAJ[12] = {8,3,10,5,12,7,2,9,4,11,6,1};   // Camelot number per major tonic
static const float PMAJ[12] = {6.35f,2.23f,3.48f,2.33f,4.38f,4.09f,2.52f,5.19f,2.39f,3.66f,2.29f,2.88f};
static const float PMIN[12] = {6.33f,2.68f,3.52f,5.38f,2.60f,3.53f,2.54f,4.75f,3.98f,2.69f,3.34f,3.17f};

inline juce::String camelotOf (int pc, bool minor) { return juce::String (MAJ[minor ? (pc + 3) % 12 : pc]) + (minor ? "A" : "B"); }
inline juce::String keyName (int pc, bool minor)   { return juce::String (NOTE[pc]) + (minor ? " minor" : " major"); }
inline int pcFromCamelot (int n, bool minor) { int maj = 0; for (int i = 0; i < 12; ++i) if (MAJ[i] == n) maj = i; return minor ? (maj + 9) % 12 : maj; }
inline int wrap12 (int n) { return ((n - 1) % 12 + 12) % 12 + 1; }

struct MixRow { juce::String code, key, type; };

struct Result
{
    bool ok = false;
    int pc = 0; bool minor = false; float conf = 0;
    double bpm = 0, seconds = 0;
    std::vector<std::pair<juce::String, float>> topChords;
    std::vector<juce::String> progression;
    std::vector<MixRow> mix;
};

inline float corr (const float* a, const float* b, int n)
{
    float ma = 0, mb = 0;
    for (int i = 0; i < n; ++i) { ma += a[i]; mb += b[i]; }
    ma /= n; mb /= n;
    float x = 0, ya = 0, yb = 0;
    for (int i = 0; i < n; ++i) { float da = a[i] - ma, db = b[i] - mb; x += da * db; ya += da * da; yb += db * db; }
    return x / std::sqrt (ya * yb + 1e-9f);
}

using Chroma = std::array<float, 12>;

inline std::vector<Chroma> chromaFrames (const std::vector<float>& x, double sr, double& hop)
{
    const int order = 13, S = 1 << order, H = S / 2;
    juce::dsp::FFT fft (order);
    juce::dsp::WindowingFunction<float> win ((size_t) S, juce::dsp::WindowingFunction<float>::hann);
    std::vector<float> buf ((size_t) S * 2);
    const int lo = (int) std::ceil (65.0 * S / sr), hi = (int) std::floor (2100.0 * S / sr);
    std::vector<int> map ((size_t) (hi - lo + 1));
    for (int k = lo; k <= hi; ++k)
        map[(size_t) (k - lo)] = (((int) std::lround (12.0 * std::log2 (k * sr / S / 440.0) + 69.0)) % 12 + 12) % 12;

    std::vector<Chroma> out;
    for (size_t p = 0; p + (size_t) S <= x.size(); p += (size_t) H)
    {
        std::copy (x.begin() + (long) p, x.begin() + (long) p + S, buf.begin());
        std::fill (buf.begin() + S, buf.end(), 0.0f);
        win.multiplyWithWindowingTable (buf.data(), (size_t) S);
        fft.performFrequencyOnlyForwardTransform (buf.data());
        Chroma c; c.fill (0.0f);
        for (int k = lo; k <= hi; ++k) c[(size_t) map[(size_t) (k - lo)]] += std::sqrt (buf[(size_t) k]);
        out.push_back (c);
    }
    hop = (double) H / sr;
    return out;
}

inline void detectKey (const std::vector<Chroma>& fr, int& pc, bool& minor, float& r)
{
    float c[12] = {};
    for (auto& f : fr) for (int i = 0; i < 12; ++i) c[i] += f[(size_t) i];
    float best = -2.0f;
    for (int t = 0; t < 12; ++t)
    {
        float rot[12];
        for (int i = 0; i < 12; ++i) rot[i] = c[(i + t) % 12];
        float a = corr (rot, PMAJ, 12), b = corr (rot, PMIN, 12);
        if (a > best) { best = a; pc = t; minor = false; }
        if (b > best) { best = b; pc = t; minor = true; }
    }
    r = best;
}

inline double detectBpm (const std::vector<float>& x, double sr)
{
    const int S = 1024, H = 512;
    juce::dsp::FFT fft (10);
    juce::dsp::WindowingFunction<float> win ((size_t) S, juce::dsp::WindowingFunction<float>::hann);
    std::vector<float> buf ((size_t) S * 2), prev ((size_t) S / 2, 0.0f), env;
    for (size_t p = 0; p + (size_t) S <= x.size(); p += (size_t) H)
    {
        std::copy (x.begin() + (long) p, x.begin() + (long) p + S, buf.begin());
        std::fill (buf.begin() + S, buf.end(), 0.0f);
        win.multiplyWithWindowingTable (buf.data(), (size_t) S);
        fft.performFrequencyOnlyForwardTransform (buf.data());
        float flux = 0;
        for (int k = 1; k < S / 2; ++k)
        {
            float m = std::log1p (10.0f * buf[(size_t) k]);
            float d = m - prev[(size_t) k];
            if (d > 0) flux += d;
            prev[(size_t) k] = m;
        }
        env.push_back (flux);
    }
    const int n = (int) env.size();
    if (n < 200) return 0;
    float mean = 0; for (float v : env) mean += v; mean /= (float) n;
    for (auto& v : env) v = std::max (0.0f, v - mean);

    const double rate = sr / H;
    double bestScore = 0, bestBpm = 100;
    for (double b = 60.0; b <= 200.0; b += 0.25)
    {
        double lag = 60.0 * rate / b, s = 0; long cnt = 0;
        for (int m = 1; m <= 4; ++m)
        {
            double L = lag * m; int i0 = (int) L; double fr = L - i0;
            for (int i = 0; i + i0 + 1 < n; ++i) { s += env[(size_t) i] * (env[(size_t) (i + i0)] * (1 - fr) + env[(size_t) (i + i0 + 1)] * fr); ++cnt; }
        }
        s /= (double) std::max (1L, cnt);
        s *= std::exp (-0.5 * std::pow (std::log2 (b / 120.0) / 0.9, 2.0));
        if (s > bestScore) { bestScore = s; bestBpm = b; }
    }
    while (bestBpm < 75) bestBpm *= 2;
    while (bestBpm > 180) bestBpm /= 2;
    return std::round (bestBpm * 2) / 2;
}

struct Tpl { juce::String name; std::array<float, 12> v; float norm; };
inline const std::vector<Tpl>& templates()
{
    static const std::vector<Tpl> t = [] {
        std::vector<Tpl> o;
        for (int r = 0; r < 12; ++r)
            for (int q = 0; q < 2; ++q)
            {
                Tpl p; p.v.fill (0.0f);
                const int iv[3] = {0, q ? 3 : 4, 7};
                for (int j = 0; j < 3; ++j) p.v[(size_t) ((r + iv[j]) % 12)] = j == 0 ? 1.2f : 1.0f;
                p.name = juce::String (NOTE[r]) + (q ? "m" : "");
                float s = 0; for (float f : p.v) s += f * f;
                p.norm = std::sqrt (s);
                o.push_back (p);
            }
        return o;
    }();
    return t;
}

inline std::vector<juce::String> detectChords (const std::vector<Chroma>& fr, double hop)
{
    const size_t seg = (size_t) std::max (4, (int) std::lround (1.5 / hop));
    std::vector<juce::String> res;
    for (size_t p = 0; p < fr.size(); p += seg)
    {
        Chroma c; c.fill (0.0f);
        for (size_t i = p; i < std::min (p + seg, fr.size()); ++i) for (size_t j = 0; j < 12; ++j) c[j] += fr[i][j];
        float nc = 0; for (float f : c) nc += f * f;
        nc = std::sqrt (nc) + 1e-9f;
        float bs = 0; juce::String bn;
        for (auto& t : templates())
        {
            float s = 0; for (size_t j = 0; j < 12; ++j) s += t.v[j] * c[j];
            s /= (nc * t.norm);
            if (s > bs) { bs = s; bn = t.name; }
        }
        res.push_back (bs > 0.72f ? bn : juce::String());
    }
    return res;
}

inline std::vector<MixRow> mixRows (int pc, bool minor)
{
    const int n = MAJ[minor ? (pc + 3) % 12 : pc];
    auto mk = [] (int num, bool mn, const char* type) {
        return MixRow { juce::String (num) + (mn ? "A" : "B"), keyName (pcFromCamelot (num, mn), mn), type };
    };
    return {
        mk (n, minor, "Same key - perfect blend"),
        mk (wrap12 (n + 1), minor, "+1 clockwise - slight energy lift"),
        mk (wrap12 (n - 1), minor, "-1 counter-clockwise - calmer energy"),
        mk (n, ! minor, "Relative major/minor - same notes, new mood"),
        MixRow { camelotOf (pc, ! minor), keyName (pc, ! minor), "Parallel key (same tonic) - big mood shift, not a safe blend" }
    };
}

// x = mono samples. Uses the middle ~100 s.
inline Result analyze (const std::vector<float>& xin, double sr)
{
    Result r;
    if (sr <= 0 || xin.size() < (size_t) (sr * 10)) return r;
    const size_t len = std::min (xin.size(), (size_t) (sr * 100)), st = (xin.size() - len) / 2;
    std::vector<float> x (xin.begin() + (long) st, xin.begin() + (long) (st + len));
    r.seconds = (double) len / sr;

    double hop = 0;
    auto fr = chromaFrames (x, sr, hop);
    if (fr.empty()) return r;
    detectKey (fr, r.pc, r.minor, r.conf);
    auto ch = detectChords (fr, hop);
    r.bpm = detectBpm (x, sr);

    std::map<juce::String, int> cnt; int tot = 0;
    for (auto& c : ch) if (c.isNotEmpty()) { ++cnt[c]; ++tot; }
    std::vector<std::pair<juce::String, int>> v (cnt.begin(), cnt.end());
    std::sort (v.begin(), v.end(), [] (auto& a, auto& b) { return a.second > b.second; });
    for (size_t i = 0; i < std::min<size_t> (8, v.size()); ++i) r.topChords.push_back ({ v[i].first, 100.0f * v[i].second / (float) std::max (1, tot) });
    for (auto& c : ch) if (c.isNotEmpty() && (r.progression.empty() || r.progression.back() != c)) r.progression.push_back (c);
    r.mix = mixRows (r.pc, r.minor);
    r.ok = true;
    return r;
}
} // namespace hm
