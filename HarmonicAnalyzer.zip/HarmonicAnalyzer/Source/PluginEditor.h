#pragma once
#include "PluginProcessor.h"

class HarmonicEditor : public juce::AudioProcessorEditor,
                       private juce::ChangeListener,
                       private juce::Timer,
                       public juce::FileDragAndDropTarget
{
public:
    explicit HarmonicEditor (HarmonicProcessor&);
    ~HarmonicEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;
    bool isInterestedInFileDrag (const juce::StringArray&) override { return true; }
    void filesDropped (const juce::StringArray& f, int, int) override { if (f.size()) proc.analyseFile (juce::File (f[0])); }

private:
    void changeListenerCallback (juce::ChangeBroadcaster*) override { refresh(); }
    void timerCallback() override;
    void refresh();

    HarmonicProcessor& proc;
    juce::TextButton loadBtn { "Load song file..." }, liveBtn { "Start live capture" };
    juce::Label statusLbl;
    juce::TextEditor out;
    std::unique_ptr<juce::FileChooser> chooser;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HarmonicEditor)
};
