#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <atomic>
#include <functional>
#include <thread>
#include "Analyzer.h"

class HarmonicProcessor : public juce::AudioProcessor, public juce::ChangeBroadcaster
{
public:
    HarmonicProcessor();
    ~HarmonicProcessor() override;

    void prepareToPlay (double sampleRate, int) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Harmonic Analyzer"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override {}
    void setStateInformation (const void*, int) override {}

    // --- analysis API (message thread) ---
    void analyseFile (const juce::File& f);
    void startCapture();
    void stopCaptureAndAnalyse();
    bool isCapturing() const { return capturing.load(); }
    double capturedSeconds() const { return sr > 0 ? capN.load() / sr : 0.0; }
    bool isBusy() const { return busy.load(); }
    hm::Result getResult() const { const juce::ScopedLock l (lock); return result; }
    juce::String getStatus() const { const juce::ScopedLock l (lock); return status; }

private:
    using Loader = std::function<bool (std::vector<float>&, double&, juce::String&)>;
    void launch (Loader loader);
    void setStatus (const juce::String& s) { const juce::ScopedLock l (lock); status = s; }

    double sr = 44100.0;
    std::vector<float> capBuf;
    std::atomic<int> capN { 0 };
    std::atomic<bool> capturing { false }, busy { false };
    std::thread worker;
    mutable juce::CriticalSection lock;
    hm::Result result;
    juce::String status { "Load a song file, or capture live audio." };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HarmonicProcessor)
};
